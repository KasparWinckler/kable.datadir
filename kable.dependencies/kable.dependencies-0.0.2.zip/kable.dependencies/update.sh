#!/bin/bash
# SPDX-FileCopyrightText: 2026 Kaspar Winckler
# SPDX-License-Identifier: GPL-3.0-or-later

LIB="lib"

rm -fr "${LIB}"
mkdir -p "${LIB}"
cd "${LIB}"
pip3 install --no-compile --target . requests-cache
cd -
