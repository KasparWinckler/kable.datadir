# SPDX-FileCopyrightText: 2026 Kaspar Winckler
# SPDX-License-Identifier: GPL-3.0-or-later

import os
import pprint
import sys
import urllib.parse

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    import xbmcvfs

    _KODI = True

except ModuleNotFoundError:
    _KODI = False


_KEY = "route"
_routes = {}


def resolve(cls=None, **kwargs):
    cls = _routes.get(kwargs.pop(_KEY, None)) or cls
    if cls:
        return cls(**kwargs)


ADDON = xbmcaddon.Addon() if _KODI else ""
ADDON_ID = ADDON.getAddonInfo("id") if _KODI else ""
ADDON_ICON = ADDON.getAddonInfo("icon") if _KODI else ""
ADDON_NAME = ADDON.getAddonInfo("name") if _KODI else ""
ADDON_VERSION = ADDON.getAddonInfo("version") if _KODI else ""
ADDON_PROFILE = (
    xbmcvfs.translatePath(ADDON.getAddonInfo("profile")) if _KODI else os.getcwd()
)
os.makedirs(ADDON_PROFILE, exist_ok=True)

HTTP_CACHE_NAME = os.path.join(ADDON_PROFILE, "http_cache")


def log(message, level=None, notification=False):
    if _KODI:
        if level is None:
            level = xbmc.LOGINFO
        xbmc.log(f"{ADDON_NAME}: {message}", level)
        if notification:
            xbmcgui.Dialog().notification(ADDON_NAME, str(message), ADDON_ICON)
    else:
        print(message)


def _set(instance, kwargs):
    setters = {
        setter.removeprefix("set").lower(): getattr(instance, setter)
        for setter in dir(instance)
        if setter.startswith("set")
    }
    errors = {}
    for name, value in kwargs.items():
        if value is None:
            continue

        try:
            match name:
                case "gameinfotag":
                    errors.update(_set(instance.getGameInfoTag(), value))
                case "musicinfotag":
                    errors.update(_set(instance.getMusicInfoTag(), value))
                case "pictureinfotag":
                    errors.update(_set(instance.getPictureInfoTag(), value))
                case "videoinfotag":
                    errors.update(_set(instance.getVideoInfoTag(), value))
                case "audiostream":
                    instance.addAudioStream(xbmc.AudioStreamDetail(**value))
                case "subtitlestream":
                    instance.addSubtitleStream(xbmc.SubtitleStreamDetail(**value))
                case "videostream":
                    instance.addVideoStream(xbmc.VideoStreamDetail(**value))
                case _:
                    setters[name](value)
        except Exception as e:
            errors[name] = e
    return errors


def _ListItem(kwargs):
    list_item = xbmcgui.ListItem(offscreen=True)
    errors = _set(list_item, kwargs)
    if errors:
        log(errors, xbmc.LOGWARNING)
    return list_item


class Item:
    _is_folder = False

    _qargs = []

    def __init_subclass__(cls, qargs=None, **kwargs):
        super().__init_subclass__(**kwargs)
        _routes[cls.__name__] = cls
        parent = cls.__bases__[0]
        parent_qargs = getattr(parent, "_qargs", [])
        cls._qargs = list({qarg: None for qarg in (qargs or []) + parent_qargs}.keys())

    def __init__(self, **kwargs):
        self.query = {qarg: kwargs.pop(qarg, None) for qarg in self._qargs}

    def get_list_item(self):
        return {}

    def get_query(self):
        return {_KEY: self.__class__.__name__} | {
            qarg: v for qarg, v in self.query.items() if v is not None
        }

    def get_query_string(self):
        return "?" + urllib.parse.urlencode(self.get_query())

    def kodi_get_directory_item(self, plugin):
        return (
            plugin + self.get_query_string(),
            self.kodi_get_list_item(),
            self._is_folder,
        )

    def kodi_get_list_item(self):
        return _ListItem(self.get_list_item())

    def kodi_open(self, plugin, handle):
        self.open()

    def open(self):
        pass

    def recurse(self, depth=0):
        indent = "  " * depth
        print(f"{indent}{self.__class__.__name__} {self.get_query_string()}")
        pprint.pprint(
            {
                "is_folder": self._is_folder,
                "list_item": self.get_list_item(),
                "open": self.open(),
            },
            indent=2,
        )
        print()


class Folder(Item):
    _is_folder = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_content()
        self.set_cache_to_disc()
        self.set_update_listing()

    def kodi_open(self, plugin, handle):
        try:
            directory_items = [
                item.kodi_get_directory_item(plugin) for item in self.open()
            ]
            xbmcplugin.addDirectoryItems(handle, directory_items)
            succeeded = True
        except Exception as e:
            directory_items = []
            succeeded = False
            log(e, xbmc.LOGERROR, notification=True)
        finally:
            xbmcplugin.setContent(handle, self._content)
            xbmcplugin.endOfDirectory(
                handle,
                cacheToDisc=self._cache_to_disc,
                succeeded=succeeded,
                updateListing=self._update_listing,
            )

    def open(self):
        return []

    def recurse(self, depth=0):
        items = list(self.open())
        indent = "  " * depth
        print(f"{indent}{self.__class__.__name__} {self.get_query_string()}")
        pprint.pprint(
            {
                "is_folder": self._is_folder,
                "list_item": self.get_list_item(),
                "list_items": len(items),
            },
            indent=2,
        )
        print()
        for item in items:
            item.recurse(depth + 1)

    def set_cache_to_disc(self, cache_to_disc=False):
        self._cache_to_disc = cache_to_disc

    def set_content(self, content=""):
        self._content = content

    def set_update_listing(self, update_listing=False):
        self._update_listing = update_listing


class Playable(Item):
    def kodi_get_list_item(self):
        list_item = super().kodi_get_list_item()
        list_item.setProperty("IsPlayable", "true")
        return list_item

    def kodi_open(self, plugin, handle):
        try:
            item = self.open()
            succeeded = True
        except Exception as e:
            item = {}
            succeeded = False
            log(e, xbmc.LOGERROR, notification=True)
        finally:
            list_item = _ListItem(item)
            xbmcplugin.setResolvedUrl(handle, succeeded, list_item)

    def open(self):
        return {}


class Search(Folder):
    def kodi_open(self, plugin, handle):
        heading = self.get_list_item().get("label") or "Search"
        self.search_string = xbmcgui.Dialog().input(heading)
        if self.search_string:
            self.set_cache_to_disc(True)
            self.set_update_listing(True)
            super().kodi_open(plugin, handle)
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False)


def kodi_run(item_class):
    plugin = sys.argv[0]
    handle = int(sys.argv[1])
    query = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    log(", ".join(f"{k}={v}" for k, v in query.items()))
    item = resolve(**query) or item_class()
    item.kodi_open(plugin, handle)
